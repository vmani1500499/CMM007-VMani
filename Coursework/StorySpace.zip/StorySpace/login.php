<?php
if (isset($_SESSION['Username_C']) && isset($_SESSION['Password_C'])&& isset($_SESSION['Login_Status'])) {
    echo "The cookie". $_COOKIE['Username_C']."is set";
    echo "The cookie". $_COOKIE['Password_C']."is set";
    echo "The cookie". $_COOKIE['Login_Status']."is set";
    $user = $_COOKIE['Username_C'];
    $password= $_COOKIE['Password_C'];
    $nameErr ='';
} else {
    echo "The cookie named 'username' is not set.";
    $user = '';
    $password = '';
    $nameErr ='';}

if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle POST request
    $user = $_POST['uname'];
    $password = $_POST['pass'];

    // Validate the form data here

} else {
    // Handle missing form fields here
    echo "Please fill in all required fields.";
}

$mysqli = new mysqli("localhost","root","","storyspace");
// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}

// Perform query
if ($result1 = mysqli_query($mysqli , "SELECT * FROM login")) {
    echo "\nReturned rows are: " . mysqli_num_rows($result1);
    // Free result set
    mysqli_free_result($result1);
}

// Perform query
if ($result2 = mysqli_query($mysqli , "SELECT * FROM login WHERE Username = '".$user."'"))
  {
    echo "\nThe user name ".$user . mysqli_num_rows($result2)." exists";
    // Free result set
    mysqli_free_result($result2);
   }

$query = "SELECT * FROM login WHERE Username = '$user' AND password = '$password'";
$result3 = mysqli_query($mysqli, $query);
echo " The user name ".$user . mysqli_num_rows($result3)." exists";
// Check if there is a result
if (mysqli_num_rows($result3) > 0) {
  echo "\n User name password correct";
    mysqli_free_result($result3);
// The user is logged in

    setcookie("Username_C", $user);
    setcookie("Password_C", $password);
    setcookie("Login_Status", 1);
// Set a cookie that expires in 1 hour
    setcookie("Username_C", $user, time() + 3600);
    setcookie("Password_C", $user, time() + 3600);
    setcookie("Login_Status", $user, time() + 3600);
    header("Location: home1.html");
} else {
    echo "\n User name password not correct";
    setcookie("Username_C", "", time() - 3600, "/");
    setcookie("Password_C", "", time() - 3600, "/");
    setcookie("Login_Status", "", time() - 3600, "/");

    unset($_COOKIE["Login_Status"]);
    unset($_COOKIE["Username_C"]);
    unset($_COOKIE["Password_C"]);

// The user is not logged in
}

mysqli_close($mysqli);
?>


<html>
<body>
<fieldset id='fld'>
    <form method='post' name='f1' action='<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>'>
        <table>
            <tr>
                <td>
                    User Name:<input type='text' id='uname' name='uname' class='uname' placeholder='USERNAME' autocomplete='off' autofocus maxlength='25'><span class='error'>*</span>
                    Password:<input type='password' id='pass' class='pass' name='pass' placeholder='PASSWORD' autocomplete='off'>
                    <input type='submit' name='submit' id='loggin' value='LOGIN' class='login' onclick='val()'>
                </td>
            </tr>
        </table>
    </form>
</fieldset>
<div class='errormsg' id='errmsg'><?php echo htmlspecialchars($nameErr);?></div>
</body>
</>

<script>
    function val() {
        // Get the values of the form inputs
        var username = document.getElementById("uname").value;
        var password = document.getElementById("pass").value;

        // Validate the inputs
        if (username == "" || password == "") {
            alert("Please enter a username and password.");
            return false;
        }

        // If the inputs are valid, return true
        return true;
    }
</script>
