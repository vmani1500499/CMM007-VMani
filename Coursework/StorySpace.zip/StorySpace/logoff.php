<?php
// Set the cookie expiration time to a time in the past
setcookie("Username_C", "", time() - 3600, "/");
setcookie("Password_C", "", time() - 3600, "/");
setcookie("Login_Status", "", time() - 3600, "/");

// Unset any other cookies that were set during the user's session
unset($_COOKIE["Username_C"]);
unset($_COOKIE["Password_C"]);
unset($_COOKIE["Login_Status"]);

// Redirect the user to the login page or another appropriate page
header("Location: home1.html");
?>


